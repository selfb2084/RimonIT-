RIMON IT ওয়েবসাইট আপলোড নির্দেশনা

১) আপনার নিজের ছবি এই assets ফোল্ডারে profile.jpg নামে রাখুন।
২) আপনার লোগো assets ফোল্ডারে logo.png নামে রাখুন।
৩) GitHub repository-তে index.html এবং সম্পূর্ণ assets ফোল্ডার আপলোড করুন।
৪) index.html অবশ্যই repository-র root-এ থাকবে।
৫) Settings > Pages থেকে Deploy from a branch, main, /(root) নির্বাচন করে Save করুন।

ছবির নাম পরিবর্তন করলে index.html-এও সেই নাম পরিবর্তন করতে হবে।